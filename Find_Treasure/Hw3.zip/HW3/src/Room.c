/*
 * Room.c
 *
 *  Created on: Sep 11, 2019
 *      Author: kushal
 */

int open(){
	int ok=0;
	return ok;
}

int haveTreasure(){
	return 0;
}

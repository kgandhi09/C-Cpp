/*
 * production.h
 *
 *  Created on: Sep 10, 2019
 *      Author: kushal
 */

#ifndef HOUSE_H_
#define HOUSE_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#include "Layout.h"

int getNumberOfRooms();
int getNewRoom();

#endif /* HOUSE_H_ */

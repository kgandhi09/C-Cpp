/*
 * Search.c
 *
 *  Created on: Sep 11, 2019
 *      Author: kushal
 */

#include "Search.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>


int getNumRooms(){
	int nRooms = countRooms();
	return nRooms;
}





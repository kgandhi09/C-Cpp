/*
 * Room.h
 *
 *  Created on: Sep 11, 2019
 *      Author: kushal
 */

#ifndef ROOM_H_
#define ROOM_H_



#endif /* ROOM_H_ */

int open();
int haveTreasure();

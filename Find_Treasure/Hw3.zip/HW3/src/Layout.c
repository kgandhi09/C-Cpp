/*
 * Layout.c
 *
 *  Created on: Sep 11, 2019
 *      Author: kushal
 */

#include "Layout.h"
//#include "production.h"

int countRooms(){
	int nRooms=0;
	return nRooms;
}

int getFirstRoom(){
	int firstRoom = open();
	return firstRoom;
}

/*
 * tests.c
 *
 *  Created on: Sep 10, 2019
 *      Author: kushal
 */

#include "tests.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "House.h"




bool tests(void)
{
	bool results=true;
	return results;
}


/*
 * Search.h
 *
 *  Created on: Sep 11, 2019
 *      Author: kushal
 */

#ifndef SEARCH_H_
#define SEARCH_H_

#include "House.h"
#include "Room.h"

int getNumRooms();

#endif /* SEARCH_H_ */



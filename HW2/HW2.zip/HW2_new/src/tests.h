/*
 * tests.h
 *
 *  Created on: Sep 6, 2019
 *      Author: kushal
 */

#include <stdbool.h>
#ifndef TESTS_H_
#define TESTS_H_

bool tests(void);
bool testGetMarkerPos();
bool testPrintArray();
bool testPlaceMarker();
bool testMoveMarker();

#endif /* TESTS_H_ */

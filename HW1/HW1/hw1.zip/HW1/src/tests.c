/*
 * tests.c
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */

#include "tests.h"
int test(){
	int result=0;

	return result;
}

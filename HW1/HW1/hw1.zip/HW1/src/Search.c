/*
 * Search.c
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */

#include "Search.h"

// int nRooms = getNumberOfRooms();
//static int aRoom = getNewRoom();

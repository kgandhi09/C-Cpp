/*
 * Layout.h
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */

#ifndef SRC_LAYOUT_H_
#define SRC_LAYOUT_H_



#endif /* SRC_LAYOUT_H_ */

#include "Room.h"

int countRooms();
int getFirstRoom();

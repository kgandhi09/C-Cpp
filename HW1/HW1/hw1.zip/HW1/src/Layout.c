/*
 * Layout.c
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */
#include "Layout.h"


int countRooms(){
	int nRooms=0;
	return nRooms;
}

int getFirstRoom(){
	int firstRoom = open();
	return firstRoom;
}

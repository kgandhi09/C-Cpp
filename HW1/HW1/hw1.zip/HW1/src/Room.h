/*
 * Room.h
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */

#ifndef SRC_ROOM_H_
#define SRC_ROOM_H_



#endif /* SRC_ROOM_H_ */

int open();
int haveTreasure();

/*
 * House.h
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */

#ifndef SRC_HOUSE_H_
#define SRC_HOUSE_H_



#endif /* SRC_HOUSE_H_ */

#include "Layout.h"

int getNumberOfRooms();
int getNewRoom();

/*
 * Room.c
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */

#include "Room.h"

int open(){
	int ok=0;
	return ok;
}

int haveTreasure(){
	return 0;
}

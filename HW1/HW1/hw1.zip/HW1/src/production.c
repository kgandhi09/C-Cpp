/*
 * production.c
 *
 *  Created on: Aug 30, 2019
 *      Author: kushal
 */
#include "production.h"


int production(int argc,char** argv){
	int result=0;
	return result;
}

/*
 * Board.c
 *
 *  Created on: Aug 25, 2019
 *      Author: Therese
 */


void displayBoard(int* board, int nRows, int nCols)
{

}


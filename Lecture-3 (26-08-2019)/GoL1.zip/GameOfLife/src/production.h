/*
 * production.h
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include "Board.h"

#define nBOARDS 3

bool production(int argc, char* argv[]);
void showBoards();

#endif /* PRODUCTION_H_ */

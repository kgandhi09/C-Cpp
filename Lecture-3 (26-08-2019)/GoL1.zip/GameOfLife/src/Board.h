/*
 * Board.h
 *
 *  Created on: Aug 25, 2019
 *      Author: Therese
 */

#ifndef BOARD_H_
#define BOARD_H_

void displayBoard(int* board, int nRows, int nCols);

#endif /* BOARD_H_ */
